# Dependency: Sample CRUD to manage TODO items

This dependency is a sample CRUD to manage TODO items in a memory list.  

You can get all list items, add a new item, remove item or update item.  

# How to generate djinni files?  

This is required if you change source code.  

Djinni is required to generate the bridge files between C++ and platform code (iOS and Android).  

1. Set environment variable **"DJINNI_HOME"** with the path of your Djinni home directory.  

2. Run:  

```python
python djinni-generate.py
```

### How to use it with Swift (can be used with Objective-C too)?

[TODO]

### How to use it with Android?

[TODO]

### How to use it with C++?

[TODO]