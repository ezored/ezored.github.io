import os
import shutil
import subprocess

# remove all old djinni files

try:
    shutil.rmtree(path='build/djinni')
except:
    pass

# data to generate files
# obs: folders need start with / if have a name

configs = [
	{
		'folder': '/ezored/sample/domain',
		'javaPackage': 'com.ezored.sample.domain',
		'javaParcelable': True,
		'cppNamespace': 'ezored::sample::domain',
		'jniSuffix': 'Domain',
		'objcSuffix': 'Domain',
		'idlFile': 'domain.djinni',
	},
	{
		'folder': '/ezored/sample/dataservices',
		'javaPackage': 'com.ezored.sample.dataservices',
		'javaParcelable': False,
		'cppNamespace': 'ezored::sample::dataservices',
		'jniSuffix': 'DataService',
		'objcSuffix': 'DataService',
		'idlFile': 'data-services.djinni',		
	}
]

# generate files

for config in configs:
	subprocess.call([
		os.environ['DJINNI_HOME'] + "/src/run",
		"--java-out", "build/djinni/java-output{0}".format(config['folder']),
		"--java-package", "{0}".format(config['javaPackage']),
		"--ident-java-field", "mFooBar",
		"--java-implement-android-os-parcelable", ("true" if config['javaParcelable'] else "false"),

		"--cpp-out", "build/djinni/cpp-output{0}".format(config['folder']),
		"--cpp-namespace", "{0}".format(config['cppNamespace']),
		"--ident-cpp-field", "fooBar",
		"--ident-cpp-method", "fooBar",
		"--ident-cpp-file", "FooBar",
		"--ident-cpp-local", "fooBar",
		
		"--ident-jni-class", "EZR{0}FooBar".format(config['jniSuffix']),
		"--ident-jni-file", "EZR{0}FooBar".format(config['jniSuffix']),
		"--jni-out", "build/djinni/jni-output{0}".format(config['folder']),	

		"--objc-out", "build/djinni/objc-output{0}".format(config['folder']),
		"--objc-type-prefix", "EZR{0}".format(config['objcSuffix']),
		"--objcpp-out", "build/djinni/objc-output{0}".format(config['folder']),

		"--yaml-out", "build/djinni/yaml{0}".format(config['folder']),
		"--idl", "djinni/{0}".format(config['idlFile'])	
	])